from neuralintents import GenericAssistant
import pandas_datareader as web
import sys
from datetime import datetime
import json
import random

stock_tickers = ['AAPL', 'FB', 'GS', 'TSLA']
todos = ['Wash car', 'Namaz prho', 'Watch Movies', 'Go shopping']


def greet_user():
    f = open('intents.json')
    data = json.load(f)
    responses = data['intents'][0]['responses']
    print(responses[random.randint(0, len(responses) - 1)])


def stock_function():
    for ticker in stock_tickers:
        data = web.get_data_yahoo(ticker, '2019-09-10',
                                  datetime.today().strftime('%Y-%m-%d'))
        print(f"The last price of {ticker} is {data['Close'].iloc[-1]}")


def todo_show():
    print("Your TODO lost: ")
    for todo in todos:
        print(todo)


def todo_Add():
    todos.append(input("What do you want to add? "))
    print("Added!")


def todo_remove():
    idx = int(input("What do you want to remove? ")) - 1
    if idx < len(todos):
        print(f"Removed! {todos[idx]}")
        todos.pop(idx)
    else:
        print("No TODO at this location!")


def bye():
    print("Bye!")
    print("Happy to meet again")
    sys.exit()


mappings = {'greeting': greet_user, 'stocks': stock_function, 'todoshow': todo_show,
            'todoadd': todo_Add, 'todoremove': todo_remove, 'goodbye': bye}

assistant = GenericAssistant(
    "intents.json", intent_methods=mappings, model_name="test_model")


assistant.train_model()
assistant.save_model()


while True:
    print("Welcome to Virtual Assistant")
    message = input("Message: ")
    assistant.request(message)
